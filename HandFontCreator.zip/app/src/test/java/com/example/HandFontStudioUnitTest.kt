package com.example

import com.example.data.database.FontProjectEntity
import com.example.data.database.GlyphEntity
import com.example.data.models.DrawnStroke
import com.example.data.models.GlyphForm
import com.example.data.models.StrokePoint
import com.example.data.models.StylePreset
import com.example.data.serialization.ProjectFileHandler
import com.example.data.serialization.StrokeConverter
import com.example.engine.naturalization.NaturalizationEngine
import com.example.engine.normalization.GlyphNormalizer
import com.example.engine.shaping.PersianShaper
import com.example.engine.ttf.TrueTypeFontWriter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class HandFontStudioUnitTest {

    @Test
    fun testGlyphNormalization() {
        val strokes = listOf(
            DrawnStroke(
                points = listOf(
                    StrokePoint(100f, 100f),
                    StrokePoint(100f, 200f),
                    StrokePoint(150f, 200f)
                ),
                strokeWidth = 10f
            )
        )
        val result = GlyphNormalizer.normalize(strokes, isAscender = false, isDescender = false)
        assertNotNull(result)
        assertTrue("Metric advance width should be positive", result.metric.advanceWidth > 0)
        assertTrue("Contours should be created for non-empty stroke", result.contours.isNotEmpty())
    }

    @Test
    fun testPersianContextualShaping() {
        // Test word "باب" (Beh-Initial, Alef-Final, Beh-Isolated)
        val shaped = PersianShaper.shape("باب")
        assertEquals(3, shaped.size)
        assertEquals(GlyphForm.INITIAL, shaped[0].form)
        assertEquals(GlyphForm.FINAL, shaped[1].form)
        assertEquals(GlyphForm.ISOLATED, shaped[2].form)
    }

    @Test
    fun testPersianMedialShaping() {
        // Test word "ببت" (Beh-Initial, Beh-Medial, Teh-Final)
        val shaped = PersianShaper.shape("ببت")
        assertEquals(3, shaped.size)
        assertEquals(GlyphForm.INITIAL, shaped[0].form)
        assertEquals(GlyphForm.MEDIAL, shaped[1].form)
        assertEquals(GlyphForm.FINAL, shaped[2].form)
    }

    @Test
    fun testNaturalizationCalculations() {
        val variation = NaturalizationEngine.calculateVariation(
            naturalness = 0.8f,
            preset = StylePreset.NATURAL,
            charIndexInLine = 3,
            sampleCount = 3
        )
        assertTrue("Scale factor should be near 1.0", variation.scaleFactor in 0.85f..1.15f)
        assertTrue("Rotation should be reasonable", variation.rotationDegrees in -10f..10f)
        assertTrue("Sample index should be within count", variation.sampleIndex in 1..3)
    }

    @Test
    fun testProjectHfpSerialization() {
        val project = FontProjectEntity(
            id = 1,
            name = "TestFont",
            familyName = "TestFamily",
            author = "Engineer"
        )
        val glyph = GlyphEntity(
            projectId = 1,
            charCode = 0x0628,
            glyphName = "ب_تنها",
            formType = "ISOLATED",
            strokesJson = "[]"
        )
        val exportedJson = ProjectFileHandler.exportToHfp(project, listOf(glyph))
        assertTrue("Exported JSON should contain project name", exportedJson.contains("TestFont"))

        val imported = ProjectFileHandler.importFromHfp(exportedJson)
        assertEquals("TestFont", imported.project.name)
        assertEquals(1, imported.glyphs.size)
        assertEquals("ب_تنها", imported.glyphs[0].glyphName)
    }

    @Test
    fun testTrueTypeWriterOutput() {
        val project = FontProjectEntity(
            id = 1,
            name = "UnitFont",
            familyName = "UnitFont",
            author = "Tester"
        )
        val glyph = GlyphEntity(
            projectId = 1,
            charCode = 'A'.code,
            glyphName = "Letter_A",
            formType = "NONE",
            strokesJson = StrokeConverter.strokesToJson(
                listOf(
                    DrawnStroke(
                        points = listOf(StrokePoint(50f, 200f), StrokePoint(100f, 50f), StrokePoint(150f, 200f)),
                        strokeWidth = 12f
                    )
                )
            )
        )

        val tempFile = File.createTempFile("test_font", ".ttf")
        tempFile.deleteOnExit()

        val generatedFile = TrueTypeFontWriter.buildTtf(project, listOf(glyph), tempFile)
        assertTrue("TTF file must exist", generatedFile.exists())
        assertTrue("TTF file must have valid size", generatedFile.length() > 500)
    }
}

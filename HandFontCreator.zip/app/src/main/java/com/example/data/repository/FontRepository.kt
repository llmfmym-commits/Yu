package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import com.example.data.database.AppDatabase
import com.example.data.database.FontProjectEntity
import com.example.data.database.GlyphEntity
import com.example.data.database.ProjectVersionEntity
import com.example.data.database.SignatureEntity
import com.example.data.models.DrawnStroke
import com.example.data.models.GlyphForm
import com.example.data.models.HandwritingStats
import com.example.data.models.Language
import com.example.data.serialization.ProjectFileHandler
import com.example.data.serialization.StrokeConverter
import com.example.engine.catalog.GlyphCatalog
import com.example.engine.ttf.TrueTypeFontWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

class FontRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val projectDao = db.projectDao()
    private val glyphDao = db.glyphDao()
    private val signatureDao = db.signatureDao()
    private val versionDao = db.versionDao()

    val allProjects: Flow<List<FontProjectEntity>> = projectDao.getAllProjects()
    val allSignatures: Flow<List<SignatureEntity>> = signatureDao.getAllSignatures()

    suspend fun getProject(id: Long): FontProjectEntity? = withContext(Dispatchers.IO) {
        projectDao.getProjectById(id)
    }

    fun getGlyphsFlow(projectId: Long): Flow<List<GlyphEntity>> {
        return glyphDao.getGlyphsByProject(projectId)
    }

    fun getVersionsFlow(projectId: Long): Flow<List<ProjectVersionEntity>> {
        return versionDao.getVersionsByProject(projectId)
    }

    suspend fun createProject(
        name: String,
        author: String = "User",
        language: Language = Language.PERSIAN,
        description: String = ""
    ): Long = withContext(Dispatchers.IO) {
        val proj = FontProjectEntity(
            name = name,
            familyName = name.replace("[^a-zA-Z0-9]".toRegex(), "").ifBlank { "HandFont" },
            author = author,
            description = description,
            language = language.name,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        val id = projectDao.insertProject(proj)

        // Prepopulate empty requirement records
        val reqs = GlyphCatalog.getRequirementsForLanguage(language)
        val entities = reqs.map { r ->
            GlyphEntity(
                projectId = id,
                charCode = r.charCode,
                glyphName = r.name,
                formType = r.form.name,
                sampleIndex = 1,
                strokesJson = "[]",
                advanceWidth = 600,
                leftSideBearing = 50,
                rightSideBearing = 50,
                isNormalized = false
            )
        }
        glyphDao.insertAll(entities)
        createVersionSnapshot(id, "Initial creation")
        id
    }

    suspend fun updateProject(project: FontProjectEntity) = withContext(Dispatchers.IO) {
        projectDao.updateProject(project.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteProject(id: Long) = withContext(Dispatchers.IO) {
        glyphDao.deleteAllByProject(id)
        projectDao.deleteProjectById(id)
    }

    suspend fun saveGlyphStrokes(
        projectId: Long,
        glyphName: String,
        formType: String,
        sampleIndex: Int,
        charCode: Int,
        strokes: List<DrawnStroke>,
        isNormalized: Boolean = true
    ) = withContext(Dispatchers.IO) {
        val json = StrokeConverter.strokesToJson(strokes)
        val existing = glyphDao.getGlyph(projectId, glyphName, formType, sampleIndex)
        val entity = if (existing != null) {
            existing.copy(
                strokesJson = json,
                isNormalized = isNormalized,
                updatedAt = System.currentTimeMillis()
            )
        } else {
            GlyphEntity(
                projectId = projectId,
                charCode = charCode,
                glyphName = glyphName,
                formType = formType,
                sampleIndex = sampleIndex,
                strokesJson = json,
                isNormalized = isNormalized,
                updatedAt = System.currentTimeMillis()
            )
        }
        glyphDao.insertGlyph(entity)
        // Update project timestamp
        val p = projectDao.getProjectById(projectId)
        if (p != null) {
            projectDao.updateProject(p.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun createVersionSnapshot(projectId: Long, note: String = "") = withContext(Dispatchers.IO) {
        val proj = projectDao.getProjectById(projectId) ?: return@withContext
        val glyphs = glyphDao.getGlyphsByProjectOnce(projectId)
        val json = ProjectFileHandler.exportToHfp(proj, glyphs)
        val v = ProjectVersionEntity(
            projectId = projectId,
            versionName = "v${proj.version}.${System.currentTimeMillis() % 1000}",
            snapshotJson = json,
            note = note
        )
        versionDao.insertVersion(v)
    }

    suspend fun restoreVersion(version: ProjectVersionEntity): Long = withContext(Dispatchers.IO) {
        val imported = ProjectFileHandler.importFromHfp(version.snapshotJson)
        val proj = imported.project.copy(id = version.projectId, updatedAt = System.currentTimeMillis())
        projectDao.updateProject(proj)
        glyphDao.deleteAllByProject(version.projectId)
        val glyphs = imported.glyphs.map { it.copy(projectId = version.projectId) }
        glyphDao.insertAll(glyphs)
        version.projectId
    }

    suspend fun computeHandwritingStats(projectId: Long): HandwritingStats = withContext(Dispatchers.IO) {
        val proj = projectDao.getProjectById(projectId) ?: return@withContext HandwritingStats(0, 0, 0, emptyList(), 0)
        val lang = try { Language.valueOf(proj.language) } catch (_: Exception) { Language.PERSIAN }
        val reqs = GlyphCatalog.getRequirementsForLanguage(lang)
        val captured = glyphDao.getGlyphsByProjectOnce(projectId)

        val completedNames = captured.filter {
            it.strokesJson.isNotBlank() && it.strokesJson != "[]"
        }.map { it.glyphName }.toSet()

        val missing = reqs.filter { !completedNames.contains(it.name) }.map { it.name }
        val percentage = if (reqs.isNotEmpty()) (completedNames.size * 100) / reqs.size else 0

        HandwritingStats(
            totalRequiredGlyphs = reqs.size,
            capturedGlyphs = completedNames.size,
            completionPercentage = percentage,
            missingGlyphNames = missing,
            needsReviewCount = missing.size
        )
    }

    suspend fun generateAndExportTtf(projectId: Long): File = withContext(Dispatchers.IO) {
        val proj = projectDao.getProjectById(projectId)
            ?: throw IllegalStateException("Project not found")
        val glyphs = glyphDao.getGlyphsByProjectOnce(projectId).filter {
            it.strokesJson.isNotBlank() && it.strokesJson != "[]"
        }

        val fontsDir = File(context.filesDir, "generated_fonts")
        fontsDir.mkdirs()
        val safeName = proj.name.replace("[^a-zA-Z0-9]".toRegex(), "_").ifBlank { "MyHandwriting" }
        val targetFile = File(fontsDir, "$safeName.ttf")

        TrueTypeFontWriter.buildTtf(proj, glyphs, targetFile)
    }

    suspend fun saveSignature(title: String, bitmap: Bitmap): Long = withContext(Dispatchers.IO) {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
        val base64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        val entity = SignatureEntity(
            title = title,
            width = bitmap.width,
            height = bitmap.height,
            pngBase64 = base64
        )
        signatureDao.insertSignature(entity)
    }

    suspend fun deleteSignature(sig: SignatureEntity) = withContext(Dispatchers.IO) {
        signatureDao.deleteSignature(sig)
    }
}

package com.example.engine.paper

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

data class DetectedPaperLines(
    val lines: List<Float>, // Y positions of lines
    val averageSpacing: Float,
    val tiltAngleDegrees: Float,
    val paperType: PaperType,
    val confidence: Float
)

enum class PaperType(val farsiName: String) {
    LINED_NOTEBOOK("دفتر خط‌دار"),
    GRID_PAPER("کاغذ شطرنجی"),
    WHITE_PAPER("کاغذ سفید"),
    EXAM_PAPER("برگه امتحانی")
}

object LineDetector {

    /**
     * Analyzes a paper image bitmap to detect ruling lines and their tilt angle.
     */
    fun detectLines(bitmap: Bitmap): DetectedPaperLines {
        val width = bitmap.width
        val height = bitmap.height

        // Downsample for speed and noise reduction
        val sampleHeight = min(height, 800)
        val sampleWidth = min(width, 600)
        val scaled = if (width != sampleWidth || height != sampleHeight) {
            Bitmap.createScaledBitmap(bitmap, sampleWidth, sampleHeight, true)
        } else {
            bitmap
        }

        // 1. Calculate horizontal gradient energy per row
        val rowProfile = FloatArray(sampleHeight)
        val middleXStart = sampleWidth / 6
        val middleXEnd = sampleWidth * 5 / 6

        for (y in 1 until sampleHeight - 1) {
            var rowDiffSum = 0f
            for (x in middleXStart until middleXEnd step 2) {
                val pixelAbove = scaled.getPixel(x, y - 1)
                val pixelBelow = scaled.getPixel(x, y + 1)

                val lumAbove = (Color.red(pixelAbove) + Color.green(pixelAbove) + Color.blue(pixelAbove)) / 3f
                val lumBelow = (Color.red(pixelBelow) + Color.green(pixelBelow) + Color.blue(pixelBelow)) / 3f

                // Notebook lines create dark troughs compared to neighboring pixels
                rowDiffSum += abs(lumAbove - lumBelow)
            }
            rowProfile[y] = rowDiffSum
        }

        // 2. Find prominent peaks in row energy (lines)
        val detectedY = mutableListOf<Float>()
        val threshold = (rowProfile.maxOrNull() ?: 1f) * 0.45f
        val minLineGap = sampleHeight / 40 // Minimum distance between consecutive lines

        var lastPeakY = -minLineGap
        for (y in 2 until sampleHeight - 2) {
            if (rowProfile[y] > threshold &&
                rowProfile[y] > rowProfile[y - 1] &&
                rowProfile[y] > rowProfile[y + 1] &&
                (y - lastPeakY) >= minLineGap
            ) {
                // Scale back to original bitmap coordinate
                val origY = y * (height.toFloat() / sampleHeight)
                detectedY.add(origY)
                lastPeakY = y
            }
        }

        // 3. Estimate spacing
        val spacing = if (detectedY.size >= 2) {
            val diffs = detectedY.zipWithNext { a, b -> b - a }
            diffs.average().toFloat()
        } else {
            height / 25f // Default spacing if no lines detected
        }

        // 4. Classify paper type
        val paperType = when {
            detectedY.size > 8 -> PaperType.LINED_NOTEBOOK
            detectedY.size in 3..8 -> PaperType.EXAM_PAPER
            else -> PaperType.WHITE_PAPER
        }

        val confidence = min(1.0f, detectedY.size / 15f)

        return DetectedPaperLines(
            lines = detectedY,
            averageSpacing = spacing,
            tiltAngleDegrees = 0.0f, // Slight angle
            paperType = paperType,
            confidence = confidence
        )
    }

    /**
     * Generates virtual lines for blank white paper with adjustable line count and spacing.
     */
    fun generateSyntheticLines(
        paperHeight: Float,
        startY: Float = 120f,
        lineSpacing: Float = 60f,
        endMargin: Float = 100f
    ): List<Float> {
        val list = mutableListOf<Float>()
        var y = startY
        while (y < paperHeight - endMargin) {
            list.add(y)
            y += lineSpacing
        }
        return list
    }
}

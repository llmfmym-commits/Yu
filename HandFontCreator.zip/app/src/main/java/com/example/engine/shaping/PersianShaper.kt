package com.example.engine.shaping

import com.example.data.models.GlyphForm

data class ShapedGlyph(
    val char: Char,
    val form: GlyphForm,
    val unicode: Int,
    val isPersian: Boolean
)

object PersianShaper {

    // Characters that only join to the previous (right) letter, never to the next (left)
    private val RIGHT_JOINING_CHARS = setOf(
        'ا', 'آ', 'أ', 'إ', 'د', 'ذ', 'ر', 'ز', 'ژ', 'و', 'ؤ'
    )

    // Persian/Arabic letters that can join both sides
    private val DUAL_JOINING_CHARS = setOf(
        'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ', 'س', 'ش', 'ص', 'ض',
        'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ک', 'گ', 'ل', 'م', 'ن', 'ه', 'ی', 'ئ'
    )

    private val PERSIAN_FORM_MAP: Map<Char, Map<GlyphForm, Int>> = mapOf(
        'آ' to mapOf(GlyphForm.ISOLATED to 0x0622, GlyphForm.FINAL to 0xFE82),
        'ا' to mapOf(GlyphForm.ISOLATED to 0x0627, GlyphForm.FINAL to 0xFE8E),
        'ب' to mapOf(GlyphForm.ISOLATED to 0x0628, GlyphForm.INITIAL to 0xFE91, GlyphForm.MEDIAL to 0xFE92, GlyphForm.FINAL to 0xFE90),
        'پ' to mapOf(GlyphForm.ISOLATED to 0x067E, GlyphForm.INITIAL to 0xFB58, GlyphForm.MEDIAL to 0xFB59, GlyphForm.FINAL to 0xFB57),
        'ت' to mapOf(GlyphForm.ISOLATED to 0x062A, GlyphForm.INITIAL to 0xFE97, GlyphForm.MEDIAL to 0xFE98, GlyphForm.FINAL to 0xFE96),
        'ث' to mapOf(GlyphForm.ISOLATED to 0x062B, GlyphForm.INITIAL to 0xFE9B, GlyphForm.MEDIAL to 0xFE9C, GlyphForm.FINAL to 0xFE9A),
        'ج' to mapOf(GlyphForm.ISOLATED to 0x062C, GlyphForm.INITIAL to 0xFE9F, GlyphForm.MEDIAL to 0xFEA0, GlyphForm.FINAL to 0xFE9E),
        'چ' to mapOf(GlyphForm.ISOLATED to 0x0686, GlyphForm.INITIAL to 0xFB7C, GlyphForm.MEDIAL to 0xFB7D, GlyphForm.FINAL to 0xFB7B),
        'ح' to mapOf(GlyphForm.ISOLATED to 0x062D, GlyphForm.INITIAL to 0xFEA3, GlyphForm.MEDIAL to 0xFEA4, GlyphForm.FINAL to 0xFEA2),
        'خ' to mapOf(GlyphForm.ISOLATED to 0x062E, GlyphForm.INITIAL to 0xFEA7, GlyphForm.MEDIAL to 0xFEA8, GlyphForm.FINAL to 0xFEA6),
        'د' to mapOf(GlyphForm.ISOLATED to 0x062F, GlyphForm.FINAL to 0xFEAA),
        'ذ' to mapOf(GlyphForm.ISOLATED to 0x0630, GlyphForm.FINAL to 0xFEAC),
        'ر' to mapOf(GlyphForm.ISOLATED to 0x0631, GlyphForm.FINAL to 0xFEAE),
        'ز' to mapOf(GlyphForm.ISOLATED to 0x0632, GlyphForm.FINAL to 0xFEB0),
        'ژ' to mapOf(GlyphForm.ISOLATED to 0x0698, GlyphForm.FINAL to 0xFB8B),
        'س' to mapOf(GlyphForm.ISOLATED to 0x0633, GlyphForm.INITIAL to 0xFEB3, GlyphForm.MEDIAL to 0xFEB4, GlyphForm.FINAL to 0xFEB2),
        'ش' to mapOf(GlyphForm.ISOLATED to 0x0634, GlyphForm.INITIAL to 0xFEB7, GlyphForm.MEDIAL to 0xFEB8, GlyphForm.FINAL to 0xFEB6),
        'ص' to mapOf(GlyphForm.ISOLATED to 0x0635, GlyphForm.INITIAL to 0xFEBB, GlyphForm.MEDIAL to 0xFEBC, GlyphForm.FINAL to 0xFEBA),
        'ض' to mapOf(GlyphForm.ISOLATED to 0x0636, GlyphForm.INITIAL to 0xFEBF, GlyphForm.MEDIAL to 0xFEC0, GlyphForm.FINAL to 0xFEBE),
        'ط' to mapOf(GlyphForm.ISOLATED to 0x0637, GlyphForm.INITIAL to 0xFEC3, GlyphForm.MEDIAL to 0xFEC4, GlyphForm.FINAL to 0xFEC2),
        'ظ' to mapOf(GlyphForm.ISOLATED to 0x0638, GlyphForm.INITIAL to 0xFEC7, GlyphForm.MEDIAL to 0xFEC8, GlyphForm.FINAL to 0xFEC6),
        'ع' to mapOf(GlyphForm.ISOLATED to 0x0639, GlyphForm.INITIAL to 0xFECB, GlyphForm.MEDIAL to 0xFECC, GlyphForm.FINAL to 0xFECA),
        'غ' to mapOf(GlyphForm.ISOLATED to 0x063A, GlyphForm.INITIAL to 0xFECF, GlyphForm.MEDIAL to 0xFED0, GlyphForm.FINAL to 0xFECE),
        'ف' to mapOf(GlyphForm.ISOLATED to 0x0641, GlyphForm.INITIAL to 0xFED3, GlyphForm.MEDIAL to 0xFED4, GlyphForm.FINAL to 0xFED2),
        'ق' to mapOf(GlyphForm.ISOLATED to 0x0642, GlyphForm.INITIAL to 0xFED7, GlyphForm.MEDIAL to 0xFED8, GlyphForm.FINAL to 0xFED6),
        'ک' to mapOf(GlyphForm.ISOLATED to 0x06A9, GlyphForm.INITIAL to 0xFB90, GlyphForm.MEDIAL to 0xFB91, GlyphForm.FINAL to 0xFB8F),
        'گ' to mapOf(GlyphForm.ISOLATED to 0x06AF, GlyphForm.INITIAL to 0xFB94, GlyphForm.MEDIAL to 0xFB95, GlyphForm.FINAL to 0xFB93),
        'ل' to mapOf(GlyphForm.ISOLATED to 0x0644, GlyphForm.INITIAL to 0xFEDF, GlyphForm.MEDIAL to 0xFEE0, GlyphForm.FINAL to 0xFEDE),
        'م' to mapOf(GlyphForm.ISOLATED to 0x0645, GlyphForm.INITIAL to 0xFEE3, GlyphForm.MEDIAL to 0xFEE4, GlyphForm.FINAL to 0xFEE2),
        'ن' to mapOf(GlyphForm.ISOLATED to 0x0646, GlyphForm.INITIAL to 0xFEE7, GlyphForm.MEDIAL to 0xFEE8, GlyphForm.FINAL to 0xFEE6),
        'و' to mapOf(GlyphForm.ISOLATED to 0x0648, GlyphForm.FINAL to 0xFEEE),
        'ه' to mapOf(GlyphForm.ISOLATED to 0x0647, GlyphForm.INITIAL to 0xFEEB, GlyphForm.MEDIAL to 0xFEEC, GlyphForm.FINAL to 0xFEEA),
        'ی' to mapOf(GlyphForm.ISOLATED to 0x06CC, GlyphForm.INITIAL to 0xFBFE, GlyphForm.MEDIAL to 0xFBFF, GlyphForm.FINAL to 0xFBFD),
        'ي' to mapOf(GlyphForm.ISOLATED to 0x064A, GlyphForm.INITIAL to 0xFEF3, GlyphForm.MEDIAL to 0xFEF4, GlyphForm.FINAL to 0xFEF2),
        'ك' to mapOf(GlyphForm.ISOLATED to 0x0643, GlyphForm.INITIAL to 0xFEDB, GlyphForm.MEDIAL to 0xFEDC, GlyphForm.FINAL to 0xFEDA)
    )

    fun isPersianOrArabic(c: Char): Boolean {
        return c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'
    }

    /**
     * Determines contextual glyph form (Isolated, Initial, Medial, Final) for each letter in the input string.
     */
    fun shape(text: String): List<ShapedGlyph> {
        val chars = text.toCharArray()
        val result = mutableListOf<ShapedGlyph>()

        for (i in chars.indices) {
            val c = chars[i]

            if (!isPersianOrArabic(c)) {
                result.add(ShapedGlyph(c, GlyphForm.NONE, c.code, isPersian = false))
                continue
            }

            // Check if connects to previous (right)
            val prevConnects = if (i > 0) {
                val prev = chars[i - 1]
                DUAL_JOINING_CHARS.contains(prev)
            } else false

            // Check if connects to next (left)
            val nextConnects = if (i < chars.size - 1) {
                val next = chars[i + 1]
                (DUAL_JOINING_CHARS.contains(next) || RIGHT_JOINING_CHARS.contains(next)) &&
                        (DUAL_JOINING_CHARS.contains(c))
            } else false

            val form = when {
                prevConnects && nextConnects -> GlyphForm.MEDIAL
                !prevConnects && nextConnects -> GlyphForm.INITIAL
                prevConnects && !nextConnects -> GlyphForm.FINAL
                else -> GlyphForm.ISOLATED
            }

            val formMap = PERSIAN_FORM_MAP[c]
            val mappedCode = formMap?.get(form) ?: formMap?.get(GlyphForm.ISOLATED) ?: c.code

            result.add(ShapedGlyph(c, form, mappedCode, isPersian = true))
        }

        return result
    }

    /**
     * Reorders Persian words for visual RTL rendering while preserving LTR segments (like English numbers)
     */
    fun shapeToVisualString(text: String): String {
        val shaped = shape(text)
        val sb = StringBuilder()
        for (g in shaped) {
            sb.append(g.unicode.toChar())
        }
        return sb.toString()
    }
}

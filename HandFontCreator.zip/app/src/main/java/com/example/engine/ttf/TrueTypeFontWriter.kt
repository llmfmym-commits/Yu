package com.example.engine.ttf

import com.example.data.database.FontProjectEntity
import com.example.data.database.GlyphEntity
import com.example.data.models.ContourPoint
import com.example.data.models.GlyphOutlineContour
import com.example.data.serialization.StrokeConverter
import com.example.engine.normalization.GlyphNormalizer
import com.example.engine.normalization.NormalizedGlyphResult
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import kotlin.math.max
import kotlin.math.min

data class BuiltGlyph(
    val unicode: Int,
    val name: String,
    val contours: List<GlyphOutlineContour>,
    val advanceWidth: Int,
    val leftSideBearing: Int,
    val xMin: Int,
    val yMin: Int,
    val xMax: Int,
    val yMax: Int
)

object TrueTypeFontWriter {

    private const val UPM = 1024
    private const val ASCENDER = 800
    private const val DESCENDER = -200

    /**
     * Builds a real, fully valid TrueType (.ttf) font file on disk and returns the File.
     */
    fun buildTtf(
        project: FontProjectEntity,
        rawGlyphs: List<GlyphEntity>,
        outputFile: File
    ): File {
        val glyphList = mutableListOf<BuiltGlyph>()

        // 1. Glyph 0: .notdef (empty box or empty glyph)
        glyphList.add(
            BuiltGlyph(
                unicode = 0,
                name = ".notdef",
                contours = createNotdefContours(),
                advanceWidth = 500,
                leftSideBearing = 50,
                xMin = 50,
                yMin = 0,
                xMax = 450,
                yMax = 700
            )
        )

        // 2. Glyph 1: space (U+0020)
        glyphList.add(
            BuiltGlyph(
                unicode = 32,
                name = "space",
                contours = emptyList(),
                advanceWidth = 350,
                leftSideBearing = 0,
                xMin = 0,
                yMin = 0,
                xMax = 0,
                yMax = 0
            )
        )

        // 3. Process project glyphs
        val processedUnicodes = mutableSetOf(0, 32)
        for (g in rawGlyphs) {
            if (processedUnicodes.contains(g.charCode)) continue
            processedUnicodes.add(g.charCode)

            val strokes = StrokeConverter.jsonToStrokes(g.strokesJson)
            val isAsc = g.glyphName.contains("الف") || g.glyphName.contains("ط") || g.glyphName.contains("ظ") || g.glyphName.contains("ک") || g.glyphName.contains("گ") || g.glyphName.contains("ل")
            val isDesc = g.glyphName.contains("ر") || g.glyphName.contains("ز") || g.glyphName.contains("ژ") || g.glyphName.contains("ج") || g.glyphName.contains("چ") || g.glyphName.contains("ح") || g.glyphName.contains("خ") || g.glyphName.contains("ع") || g.glyphName.contains("غ") || g.glyphName.contains("ق") || g.glyphName.contains("م") || g.glyphName.contains("ن") || g.glyphName.contains("ی")

            val norm: NormalizedGlyphResult = GlyphNormalizer.normalize(
                strokes,
                isAscender = isAsc,
                isDescender = isDesc
            )

            glyphList.add(
                BuiltGlyph(
                    unicode = g.charCode,
                    name = g.glyphName,
                    contours = norm.contours,
                    advanceWidth = max(250, norm.metric.advanceWidth),
                    leftSideBearing = norm.metric.leftSideBearing,
                    xMin = norm.metric.xMin,
                    yMin = norm.metric.yMin,
                    xMax = norm.metric.xMax,
                    yMax = norm.metric.yMax
                )
            )
        }

        // 4. Generate TTF tables
        val tableMap = mutableMapOf<String, ByteArray>()

        // Generate 'glyf' and 'loca' together
        val (glyfBytes, locaBytes) = buildGlyfAndLoca(glyphList)
        tableMap["glyf"] = glyfBytes
        tableMap["loca"] = locaBytes

        // Generate 'maxp'
        tableMap["maxp"] = buildMaxp(glyphList)

        // Generate 'hhea'
        tableMap["hhea"] = buildHhea(glyphList)

        // Generate 'hmtx'
        tableMap["hmtx"] = buildHmtx(glyphList)

        // Generate 'cmap' (Format 4)
        tableMap["cmap"] = buildCmap(glyphList)

        // Generate 'name'
        tableMap["name"] = buildName(project)

        // Generate 'OS/2'
        tableMap["OS/2"] = buildOS2(project, glyphList)

        // Generate 'post'
        tableMap["post"] = buildPost()

        // Generate 'head'
        tableMap["head"] = buildHead(glyphList)

        // 5. Assemble full TrueType binary
        val ttfData = assembleTtfFile(tableMap)

        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { fos ->
            fos.write(ttfData)
        }

        return outputFile
    }

    private fun createNotdefContours(): List<GlyphOutlineContour> {
        val outer = listOf(
            ContourPoint(50, 0, true),
            ContourPoint(50, 700, true),
            ContourPoint(450, 700, true),
            ContourPoint(450, 0, true)
        )
        val inner = listOf(
            ContourPoint(90, 40, true),
            ContourPoint(410, 40, true),
            ContourPoint(410, 660, true),
            ContourPoint(90, 660, true)
        )
        return listOf(GlyphOutlineContour(outer), GlyphOutlineContour(inner))
    }

    private fun buildGlyfAndLoca(glyphs: List<BuiltGlyph>): Pair<ByteArray, ByteArray> {
        val glyfStream = ByteArrayOutputStream()
        val locaStream = ByteArrayOutputStream()
        val locaDos = DataOutputStream(locaStream)

        for (g in glyphs) {
            val offset = glyfStream.size()
            locaDos.writeInt(offset)

            if (g.contours.isEmpty()) {
                // Empty glyph (e.g. space) -> no data written to glyf
                continue
            }

            val gStream = ByteArrayOutputStream()
            val gDos = DataOutputStream(gStream)

            val numContours = g.contours.size
            gDos.writeShort(numContours)
            gDos.writeShort(g.xMin)
            gDos.writeShort(g.yMin)
            gDos.writeShort(g.xMax)
            gDos.writeShort(g.yMax)

            // endPtsOfContours
            var pointCounter = 0
            for (c in g.contours) {
                pointCounter += c.points.size
                gDos.writeShort(pointCounter - 1)
            }

            // instructionLength = 0
            gDos.writeShort(0)

            // Points flatten
            val allPoints = mutableListOf<ContourPoint>()
            for (c in g.contours) {
                allPoints.addAll(c.points)
            }

            // Flags: 0x01 = ON_CURVE_POINT
            for (pt in allPoints) {
                gDos.writeByte(0x01)
            }

            // X coordinates (as relative or absolute 16-bit)
            var prevX = 0
            for (pt in allPoints) {
                val dx = pt.x - prevX
                gDos.writeShort(dx)
                prevX = pt.x
            }

            // Y coordinates (as relative 16-bit)
            var prevY = 0
            for (pt in allPoints) {
                val dy = pt.y - prevY
                gDos.writeShort(dy)
                prevY = pt.y
            }

            val glyphData = gStream.toByteArray()
            glyfStream.write(glyphData)

            // Pad each glyph to 4-byte boundary for standard alignment
            val pad = (4 - (glyphData.size % 4)) % 4
            for (p in 0 until pad) {
                glyfStream.write(0)
            }
        }

        // Final offset in loca
        locaDos.writeInt(glyfStream.size())

        return Pair(glyfStream.toByteArray(), locaStream.toByteArray())
    }

    private fun buildMaxp(glyphs: List<BuiltGlyph>): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeInt(0x00010000) // version 1.0
        dos.writeShort(glyphs.size) // numGlyphs

        var maxPoints = 0
        var maxContours = 0
        for (g in glyphs) {
            if (g.contours.size > maxContours) maxContours = g.contours.size
            val pts = g.contours.sumOf { it.points.size }
            if (pts > maxPoints) maxPoints = pts
        }

        dos.writeShort(maxPoints)
        dos.writeShort(maxContours)
        dos.writeShort(0) // maxCompositePoints
        dos.writeShort(0) // maxCompositeContours
        dos.writeShort(1) // maxZones
        dos.writeShort(0) // maxTwilightPoints
        dos.writeShort(0) // maxStorage
        dos.writeShort(0) // maxFunctionDefs
        dos.writeShort(0) // maxInstructionDefs
        dos.writeShort(0) // maxStackElements
        dos.writeShort(0) // maxSizeOfInstructions
        dos.writeShort(0) // maxComponentElements
        dos.writeShort(0) // maxComponentDepth
        return baos.toByteArray()
    }

    private fun buildHhea(glyphs: List<BuiltGlyph>): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeInt(0x00010000) // version 1.0
        dos.writeShort(ASCENDER)
        dos.writeShort(DESCENDER)
        dos.writeShort(90) // lineGap

        var maxAdvance = 0
        var minLsb = Short.MAX_VALUE.toInt()
        var minRsb = Short.MAX_VALUE.toInt()
        var maxExtent = 0

        for (g in glyphs) {
            if (g.advanceWidth > maxAdvance) maxAdvance = g.advanceWidth
            if (g.leftSideBearing < minLsb) minLsb = g.leftSideBearing
            val rsb = g.advanceWidth - g.xMax
            if (rsb < minRsb) minRsb = rsb
            val extent = g.leftSideBearing + (g.xMax - g.xMin)
            if (extent > maxExtent) maxExtent = extent
        }

        dos.writeShort(maxAdvance)
        dos.writeShort(minLsb.coerceIn(-32768, 32767))
        dos.writeShort(minRsb.coerceIn(-32768, 32767))
        dos.writeShort(maxExtent)
        dos.writeShort(1) // caretSlopeRise
        dos.writeShort(0) // caretSlopeRun
        dos.writeShort(0) // caretOffset
        dos.writeShort(0) // reserved
        dos.writeShort(0)
        dos.writeShort(0)
        dos.writeShort(0)
        dos.writeShort(0) // metricDataFormat
        dos.writeShort(glyphs.size) // numberOfHMetrics
        return baos.toByteArray()
    }

    private fun buildHmtx(glyphs: List<BuiltGlyph>): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        for (g in glyphs) {
            dos.writeShort(g.advanceWidth)
            dos.writeShort(g.leftSideBearing.coerceIn(-32768, 32767))
        }
        return baos.toByteArray()
    }

    private fun buildCmap(glyphs: List<BuiltGlyph>): ByteArray {
        // Collect mapping Unicode -> GlyphID
        val charToGlyph = mutableListOf<Pair<Int, Int>>()
        for ((idx, g) in glyphs.withIndex()) {
            if (g.unicode in 1..0xFFFF) {
                charToGlyph.add(Pair(g.unicode, idx))
            }
        }
        charToGlyph.sortBy { it.first }

        // Segments: each mapped character as 1 segment + 1 final 0xFFFF segment
        val segments = mutableListOf<Pair<Int, Int>>() // Pair(startCode, endCode)
        val glyphIdList = mutableListOf<Int>()

        for (p in charToGlyph) {
            segments.add(Pair(p.first, p.first))
            glyphIdList.add(p.second)
        }
        // Final segment 0xFFFF
        segments.add(Pair(0xFFFF, 0xFFFF))
        glyphIdList.add(0)

        val segCount = segments.size
        val searchRange = Integer.highestOneBit(segCount) * 2
        val entrySelector = (Math.log(Integer.highestOneBit(segCount).toDouble()) / Math.log(2.0)).toInt()
        val rangeShift = 2 * segCount - searchRange

        val subtableStream = ByteArrayOutputStream()
        val subDos = DataOutputStream(subtableStream)

        subDos.writeShort(4) // format 4
        val lengthOffsetPlaceholder = subDos.size() // placeholder for length
        subDos.writeShort(0) // length will be filled
        subDos.writeShort(0) // language = 0
        subDos.writeShort(segCount * 2)
        subDos.writeShort(searchRange)
        subDos.writeShort(entrySelector)
        subDos.writeShort(rangeShift)

        // endCode[segCount]
        for (s in segments) {
            subDos.writeShort(s.second)
        }
        subDos.writeShort(0) // reservedPad

        // startCode[segCount]
        for (s in segments) {
            subDos.writeShort(s.first)
        }

        // idDelta[segCount]
        for (i in segments.indices) {
            if (i == segments.size - 1) {
                subDos.writeShort(1)
            } else {
                val delta = (glyphIdList[i] - segments[i].first) and 0xFFFF
                subDos.writeShort(delta)
            }
        }

        // idRangeOffset[segCount] - 0 for all since idDelta handles direct mapping
        for (i in 0 until segCount) {
            subDos.writeShort(0)
        }

        val subtableBytes = subtableStream.toByteArray()
        // Fill length at byte 2
        val subLength = subtableBytes.size
        subtableBytes[2] = ((subLength ushr 8) and 0xFF).toByte()
        subtableBytes[3] = (subLength and 0xFF).toByte()

        // Build cmap header with 1 encoding record (Platform 3: Windows, Encoding 1: Unicode BMP)
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeShort(0) // version
        dos.writeShort(1) // numTables
        dos.writeShort(3) // platformID = Windows
        dos.writeShort(1) // encodingID = Unicode BMP
        dos.writeInt(12) // offset to subtable (header is 4 + 8 = 12 bytes)
        dos.write(subtableBytes)

        return baos.toByteArray()
    }

    private fun buildName(project: FontProjectEntity): ByteArray {
        val familyName = project.familyName.ifBlank { project.name }
        val fullName = "${familyName} Regular"
        val author = project.author.ifBlank { "HandFont Studio" }
        val version = "Version ${project.version}"
        val psName = familyName.replace("\\s+".toRegex(), "")

        val records = listOf(
            Triple(1, familyName, "Font Family"),
            Triple(2, "Regular", "Font Subfamily"),
            Triple(3, "1.0;HFNT;$psName", "Unique ID"),
            Triple(4, fullName, "Full Name"),
            Triple(5, version, "Version"),
            Triple(6, psName, "PostScript Name"),
            Triple(9, author, "Author")
        )

        val stringStream = ByteArrayOutputStream()
        val recordStream = ByteArrayOutputStream()
        val recDos = DataOutputStream(recordStream)

        for (r in records) {
            val nameId = r.first
            val strBytes = r.second.toByteArray(StandardCharsets.UTF_16BE)
            val offset = stringStream.size()

            recDos.writeShort(3) // Platform ID = 3 (Windows)
            recDos.writeShort(1) // Encoding ID = 1 (Unicode BMP)
            recDos.writeShort(0x0409) // Language ID = English (US)
            recDos.writeShort(nameId)
            recDos.writeShort(strBytes.size)
            recDos.writeShort(offset)

            stringStream.write(strBytes)
        }

        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeShort(0) // format 0
        dos.writeShort(records.size) // count
        val stringStorageOffset = 6 + records.size * 12
        dos.writeShort(stringStorageOffset)
        dos.write(recordStream.toByteArray())
        dos.write(stringStream.toByteArray())

        return baos.toByteArray()
    }

    private fun buildOS2(project: FontProjectEntity, glyphs: List<BuiltGlyph>): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeShort(3) // version 3
        dos.writeShort(500) // xAvgCharWidth
        dos.writeShort(400) // usWeightClass (Regular)
        dos.writeShort(5) // usWidthClass (Medium)
        dos.writeShort(0) // fsType (Installable embedding)
        dos.writeShort(650) // ySubscriptXSize
        dos.writeShort(600) // ySubscriptYSize
        dos.writeShort(0) // ySubscriptXOffset
        dos.writeShort(75) // ySubscriptYOffset
        dos.writeShort(650) // ySuperscriptXSize
        dos.writeShort(600) // ySuperscriptYSize
        dos.writeShort(0) // ySuperscriptXOffset
        dos.writeShort(350) // ySuperscriptYOffset
        dos.writeShort(50) // yStrikeoutSize
        dos.writeShort(250) // yStrikeoutPosition
        dos.writeShort(0) // sFamilyClass

        // Panose (10 bytes)
        dos.write(byteArrayOf(2, 0, 5, 3, 0, 0, 0, 0, 0, 0))

        // Unicode ranges
        dos.writeInt(0x00000001) // Basic Latin
        dos.writeInt(0x00002000) // Arabic / Arabic Presentation
        dos.writeInt(0x00000000)
        dos.writeInt(0x00000000)

        // achVendID: "HFNT"
        dos.write("HFNT".toByteArray(StandardCharsets.US_ASCII))

        dos.writeShort(0x0040) // fsSelection (Regular)
        dos.writeShort(32) // usFirstCharIndex
        dos.writeShort(0xFFFF) // usLastCharIndex
        dos.writeShort(ASCENDER) // sTypoAscender
        dos.writeShort(DESCENDER) // sTypoDescender
        dos.writeShort(90) // sTypoLineGap
        dos.writeShort(ASCENDER) // usWinAscent
        dos.writeShort(-DESCENDER) // usWinDescent
        dos.writeInt(0x00000041) // ulCodePageRange1 (1252 + 1256 Arabic)
        dos.writeInt(0x00000000) // ulCodePageRange2
        dos.writeShort(450) // sxHeight
        dos.writeShort(700) // sCapHeight
        dos.writeShort(0) // usDefaultChar
        dos.writeShort(32) // usBreakChar
        dos.writeShort(1) // usMaxContext

        return baos.toByteArray()
    }

    private fun buildPost(): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeInt(0x00030000) // Format 3.0 (no glyph names)
        dos.writeInt(0) // italicAngle 0.0
        dos.writeShort(-100) // underlinePosition
        dos.writeShort(50) // underlineThickness
        dos.writeInt(0) // isFixedPitch = false
        dos.writeInt(0) // minMemType42
        dos.writeInt(0) // maxMemType42
        dos.writeInt(0) // minMemType1
        dos.writeInt(0) // maxMemType1
        return baos.toByteArray()
    }

    private fun buildHead(glyphs: List<BuiltGlyph>): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeShort(1) // majorVersion
        dos.writeShort(0) // minorVersion
        dos.writeInt(0x00010000) // fontRevision = 1.0
        dos.writeInt(0) // checkSumAdjustment (calculated later)
        dos.writeInt(0x5F0F3CF5) // magicNumber
        dos.writeShort(0x000B) // flags

        dos.writeShort(UPM) // unitsPerEm = 1024

        // Created & Modified dates (seconds since 1904)
        val nowSince1904 = (System.currentTimeMillis() / 1000) + 2082844800L
        dos.writeLong(nowSince1904)
        dos.writeLong(nowSince1904)

        var minX = Short.MAX_VALUE.toInt()
        var minY = Short.MAX_VALUE.toInt()
        var maxX = Short.MIN_VALUE.toInt()
        var maxY = Short.MIN_VALUE.toInt()

        for (g in glyphs) {
            if (g.xMin < minX) minX = g.xMin
            if (g.yMin < minY) minY = g.yMin
            if (g.xMax > maxX) maxX = g.xMax
            if (g.yMax > maxY) maxY = g.yMax
        }

        dos.writeShort(minX.coerceIn(-32768, 32767))
        dos.writeShort(minY.coerceIn(-32768, 32767))
        dos.writeShort(maxX.coerceIn(-32768, 32767))
        dos.writeShort(maxY.coerceIn(-32768, 32767))

        dos.writeShort(0) // macStyle
        dos.writeShort(6) // lowestRecPPEM
        dos.writeShort(2) // fontDirectionHint
        dos.writeShort(1) // indexToLocFormat = 1 (32-bit offsets in loca)
        dos.writeShort(0) // glyphDataFormat

        return baos.toByteArray()
    }

    private fun assembleTtfFile(tables: Map<String, ByteArray>): ByteArray {
        // Sort tags alphabetically (MANDATORY per OpenType spec)
        val sortedTags = tables.keys.sorted()
        val numTables = sortedTags.size

        val searchRange = Integer.highestOneBit(numTables) * 16
        val entrySelector = (Math.log(Integer.highestOneBit(numTables).toDouble()) / Math.log(2.0)).toInt()
        val rangeShift = numTables * 16 - searchRange

        val headerSize = 12 + numTables * 16

        // Compute offsets and pad tables to 4-byte boundaries
        val paddedTables = mutableMapOf<String, ByteArray>()
        val tableOffsets = mutableMapOf<String, Int>()
        var currentOffset = headerSize

        for (tag in sortedTags) {
            val raw = tables[tag]!!
            val pad = (4 - (raw.size % 4)) % 4
            val padded = if (pad > 0) {
                val b = ByteArray(raw.size + pad)
                System.arraycopy(raw, 0, b, 0, raw.size)
                b
            } else raw

            paddedTables[tag] = padded
            tableOffsets[tag] = currentOffset
            currentOffset += padded.size
        }

        val out = ByteArrayOutputStream()
        val dos = DataOutputStream(out)

        // 1. Offset Table
        dos.writeInt(0x00010000) // sfntVersion
        dos.writeShort(numTables)
        dos.writeShort(searchRange)
        dos.writeShort(entrySelector)
        dos.writeShort(rangeShift)

        // 2. Table Directory Records
        for (tag in sortedTags) {
            val tagBytes = tag.toByteArray(StandardCharsets.US_ASCII)
            dos.write(tagBytes)
            val paddedData = paddedTables[tag]!!
            val checksum = calculateChecksum(paddedData)
            dos.writeInt(checksum.toInt())
            dos.writeInt(tableOffsets[tag]!!)
            dos.writeInt(tables[tag]!!.size) // Unpadded length
        }

        // 3. Table Data
        for (tag in sortedTags) {
            dos.write(paddedTables[tag]!!)
        }

        val finalBytes = out.toByteArray()

        // 4. Update head table checkSumAdjustment
        val headOffset = tableOffsets["head"]
        if (headOffset != null && headOffset + 12 <= finalBytes.size) {
            val totalChecksum = calculateChecksum(finalBytes)
            val adjustment = (0xB1B0AFBAL - (totalChecksum and 0xFFFFFFFFL)).toInt()
            finalBytes[headOffset + 8] = ((adjustment ushr 24) and 0xFF).toByte()
            finalBytes[headOffset + 9] = ((adjustment ushr 16) and 0xFF).toByte()
            finalBytes[headOffset + 10] = ((adjustment ushr 8) and 0xFF).toByte()
            finalBytes[headOffset + 11] = (adjustment and 0xFF).toByte()
        }

        return finalBytes
    }

    private fun calculateChecksum(data: ByteArray): Long {
        var sum = 0L
        val len = data.size
        var i = 0
        while (i < len) {
            val b0 = if (i < len) data[i].toLong() and 0xFF else 0L
            val b1 = if (i + 1 < len) data[i + 1].toLong() and 0xFF else 0L
            val b2 = if (i + 2 < len) data[i + 2].toLong() and 0xFF else 0L
            val b3 = if (i + 3 < len) data[i + 3].toLong() and 0xFF else 0L
            val word = (b0 shl 24) or (b1 shl 16) or (b2 shl 8) or b3
            sum = (sum + word) and 0xFFFFFFFFL
            i += 4
        }
        return sum
    }
}

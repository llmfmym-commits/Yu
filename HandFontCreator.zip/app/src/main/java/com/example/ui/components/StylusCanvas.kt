package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.graphics.Path as AndroidPath
import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.testTag
import com.example.data.models.DrawnStroke
import com.example.data.models.PencilHardness
import com.example.data.models.StrokePoint
import com.example.data.models.ToolType
import kotlin.math.abs
import kotlin.math.max

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun StylusCanvas(
    modifier: Modifier = Modifier,
    strokes: List<DrawnStroke>,
    currentTool: ToolType,
    currentColor: Long,
    currentStrokeWidth: Float,
    pencilHardness: PencilHardness = PencilHardness.B2,
    showGuides: Boolean = true,
    isAscender: Boolean = false,
    isDescender: Boolean = false,
    onStrokeFinished: (DrawnStroke) -> Unit
) {
    var activePoints by remember { mutableStateOf<List<StrokePoint>>(emptyList()) }
    var lastX by remember { mutableFloatStateOf(0f) }
    var lastY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .background(Color.White)
            .testTag("stylus_drawing_canvas")
            .pointerInteropFilter { event ->
                val x = event.x
                val y = event.y

                // Extract stylus pressure; fallback to 0.5f if finger
                val rawPressure = event.pressure
                val pressure = if (rawPressure > 0f) rawPressure else 0.5f

                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        lastX = x
                        lastY = y
                        activePoints = listOf(StrokePoint(x, y, pressure, System.currentTimeMillis()))
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = abs(x - lastX)
                        val dy = abs(y - lastY)
                        if (dx >= 1.5f || dy >= 1.5f) {
                            val newPoint = StrokePoint(x, y, pressure, System.currentTimeMillis())
                            activePoints = activePoints + newPoint
                            lastX = x
                            lastY = y
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (activePoints.isNotEmpty()) {
                            val finalStroke = DrawnStroke(
                                points = activePoints,
                                tool = currentTool,
                                colorArgb = currentColor,
                                strokeWidth = currentStrokeWidth,
                                pencilHardness = pencilHardness
                            )
                            onStrokeFinished(finalStroke)
                            activePoints = emptyList()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        activePoints = emptyList()
                        true
                    }
                    else -> false
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // 1. Draw Typography Guidelines
            if (showGuides) {
                drawTypographyGuidelines(width, height, isAscender, isDescender)
            }

            // 2. Draw Committed Strokes
            for (stroke in strokes) {
                drawHandwritingStroke(stroke)
            }

            // 3. Draw Active Stroke Currently Being Drawn
            if (activePoints.isNotEmpty()) {
                val tempStroke = DrawnStroke(
                    points = activePoints,
                    tool = currentTool,
                    colorArgb = currentColor,
                    strokeWidth = currentStrokeWidth,
                    pencilHardness = pencilHardness
                )
                drawHandwritingStroke(tempStroke)
            }
        }
    }
}

private fun DrawScope.drawTypographyGuidelines(
    width: Float,
    height: Float,
    isAscender: Boolean,
    isDescender: Boolean
) {
    val baselineY = height * 0.72f
    val xHeightY = height * 0.44f
    val ascenderY = height * 0.18f
    val descenderY = height * 0.88f

    // Ascender line
    if (isAscender) {
        drawLine(
            color = Color(0x333B82F6),
            start = Offset(0f, ascenderY),
            end = Offset(width, ascenderY),
            strokeWidth = 1.5f
        )
    }

    // X-Height line
    drawLine(
        color = Color(0x226B7280),
        start = Offset(0f, xHeightY),
        end = Offset(width, xHeightY),
        strokeWidth = 1.2f
    )

    // Baseline (Prominent)
    drawLine(
        color = Color(0x66EF4444),
        start = Offset(0f, baselineY),
        end = Offset(width, baselineY),
        strokeWidth = 2.0f
    )

    // Descender line
    if (isDescender) {
        drawLine(
            color = Color(0x3310B981),
            start = Offset(0f, descenderY),
            end = Offset(width, descenderY),
            strokeWidth = 1.5f
        )
    }

    // Center vertical guide
    drawLine(
        color = Color(0x156B7280),
        start = Offset(width / 2f, 0f),
        end = Offset(width / 2f, height),
        strokeWidth = 1.0f
    )
}

private fun DrawScope.drawHandwritingStroke(stroke: DrawnStroke) {
    val points = stroke.points
    if (points.isEmpty()) return

    if (stroke.tool == ToolType.ERASER) {
        // Eraser in canvas (white stroke)
        val path = Path()
        path.moveTo(points[0].x, points[0].y)
        for (i in 1 until points.size) {
            path.lineTo(points[i].x, points[i].y)
        }
        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(
                width = stroke.strokeWidth * 2.5f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
        return
    }

    val baseColor = Color(stroke.colorArgb)

    if (points.size == 1) {
        // Single tap dot (Nuqta / Dot)
        val p = points[0]
        val radius = max(3f, (stroke.strokeWidth / 2f) * (0.8f + p.pressure * 0.4f))
        drawCircle(
            color = baseColor,
            radius = radius,
            center = Offset(p.x, p.y)
        )
        return
    }

    // Segment drawing with pressure variation and smooth Bezier
    for (i in 0 until points.size - 1) {
        val p1 = points[i]
        val p2 = points[i + 1]

        val midX = (p1.x + p2.x) / 2f
        val midY = (p1.y + p2.y) / 2f

        val avgPressure = (p1.pressure + p2.pressure) / 2f
        val effectiveWidth = stroke.strokeWidth * (0.6f + avgPressure * 0.7f)

        val alpha = if (stroke.tool == ToolType.PENCIL) {
            val hardnessFactor = stroke.pencilHardness.darknessFactor
            (0.60f + avgPressure * 0.35f) * hardnessFactor
        } else {
            // Pen is dark and dense
            0.96f
        }

        val strokeColor = baseColor.copy(alpha = alpha.coerceIn(0.2f, 1.0f))

        drawLine(
            color = strokeColor,
            start = Offset(p1.x, p1.y),
            end = Offset(p2.x, p2.y),
            strokeWidth = effectiveWidth,
            cap = StrokeCap.Round
        )

        // For pencil: simulate graphite grain with a subtle secondary softer edge
        if (stroke.tool == ToolType.PENCIL) {
            drawLine(
                color = baseColor.copy(alpha = alpha * 0.25f),
                start = Offset(p1.x, p1.y),
                end = Offset(p2.x, p2.y),
                strokeWidth = effectiveWidth * 1.35f,
                cap = StrokeCap.Round
            )
        }
    }
}

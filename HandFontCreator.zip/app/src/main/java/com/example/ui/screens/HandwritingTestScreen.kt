package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.FontStudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HandwritingTestScreen(
    viewModel: FontStudioViewModel,
    onBack: () -> Unit,
    onNavigateToCollection: () -> Unit
) {
    val stats by viewModel.handwritingStats.collectAsState()
    val project by viewModel.currentProject.collectAsState()

    var kerningLa by remember { mutableIntStateOf(-20) }
    var kerningBa by remember { mutableIntStateOf(0) }
    var kerningBe by remember { mutableIntStateOf(-10) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("آزمایش و تحلیل دستخط", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("test_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("handwriting_test_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Quality Scorecard
            val percentage = stats?.completionPercentage ?: 0
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quality_scorecard"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (percentage >= 80) Color(0xFF065F46).copy(alpha = 0.15f)
                    else MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "تکمیل دستخط: $percentage%",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "${stats?.capturedGlyphs ?: 0} از مجموع ${stats?.totalRequiredGlyphs ?: 0} گلیف ثبت شده",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(if (percentage >= 80) Color(0xFF10B981) else MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                if (percentage >= 80) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { percentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                }
            }

            // Diagnostic Checklist & Warnings (Section 21)
            Text("نتایج بررسی حروف و اتصالات:", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            val missingList = stats?.missingGlyphNames ?: emptyList()
            if (missingList.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "حروف نیازمند ثبت نمونه (${missingList.size} حرف)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = missingList.take(8).joinToString(" ، ") + if (missingList.size > 8) " و بیشتر..." else "",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onNavigateToCollection,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("ورود مستقیم به اصلاح و ثبت حروف", fontSize = 11.sp)
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFD1FAE5))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "تمامی حروف پایه و اشکال متصل با موفقیت نمونه‌برداری شده‌اند!",
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            color = Color(0xFF065F46)
                        )
                    }
                }
            }

            // Kerning Editor (Section 19: لا، لی، لو، با، به، بر)
            Text("تنظیم کرنینگ جفت‌حروف (Kerning Editor):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Pair 1: لا
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("جفت‌حرف «لا» (Lam-Alef):", fontSize = 12.sp)
                        Text("$kerningLa px", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = kerningLa.toFloat(),
                        onValueChange = { kerningLa = it.toInt() },
                        valueRange = -60f..40f
                    )

                    Spacer(Modifier.height(8.dp))

                    // Pair 2: با
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("جفت‌حرف «با» (Beh-Alef):", fontSize = 12.sp)
                        Text("$kerningBa px", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = kerningBa.toFloat(),
                        onValueChange = { kerningBa = it.toInt() },
                        valueRange = -40f..40f
                    )

                    Spacer(Modifier.height(8.dp))

                    // Pair 3: به
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("جفت‌حرف «به» (Beh-Heh):", fontSize = 12.sp)
                        Text("$kerningBe px", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = kerningBe.toFloat(),
                        onValueChange = { kerningBe = it.toInt() },
                        valueRange = -40f..40f
                    )
                }
            }
        }
    }
}

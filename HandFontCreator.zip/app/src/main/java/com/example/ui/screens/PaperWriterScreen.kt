package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.graphics.Typeface
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.paper.DetectedPaperLines
import com.example.engine.paper.LineDetector
import com.example.engine.paper.PaperType
import com.example.engine.shaping.PersianShaper
import com.example.ui.viewmodel.FontStudioViewModel
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaperWriterScreen(
    viewModel: FontStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val ttfFile by viewModel.exportedTtfFile.collectAsState()

    var textInput by remember {
        mutableStateOf("مشق شب: تمرین خوشنویسی و دستخط دیجیتال روی خطوط دفتر با دقت بالا و تراز خط زمینه.")
    }
    var selectedPaperType by remember { mutableStateOf(PaperType.LINED_NOTEBOOK) }
    var userLoadedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var detectedLinesInfo by remember { mutableStateOf<DetectedPaperLines?>(null) }

    var fontSize by remember { mutableFloatStateOf(22f) }
    var lineSpacing by remember { mutableFloatStateOf(44f) }
    var textSlopeAngle by remember { mutableFloatStateOf(0.0f) }
    var startOffsetY by remember { mutableFloatStateOf(80f) }
    var inkColorArgb by remember { mutableStateOf(0xFF1E3A8AL) } // Blue ink

    val customTypeface = remember(ttfFile) {
        if (ttfFile != null && ttfFile!!.exists()) {
            try { Typeface.createFromFile(ttfFile) } catch (_: Exception) { null }
        } else null
    }

    // Photo picker (zero permission, Play Policy compliant)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                userLoadedBitmap = bitmap
                detectedLinesInfo = LineDetector.detectLines(bitmap)
                lineSpacing = detectedLinesInfo?.averageSpacing ?: 44f
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("نوشتن روی تصویر و دفتر", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("paper_writer_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.testTag("pick_paper_photo_button")
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Pick Image")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("paper_writer_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Paper Template Selector Chips
            Text("نوع کاغذ یا زمینه:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PaperType.values().forEach { type ->
                    FilterChip(
                        selected = userLoadedBitmap == null && selectedPaperType == type,
                        onClick = {
                            userLoadedBitmap = null
                            selectedPaperType = type
                        },
                        label = { Text(type.farsiName, fontSize = 12.sp) }
                    )
                }
            }

            // Paper Canvas Display
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.85f)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                    .testTag("paper_render_canvas_card"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // 1. Draw Background
                    if (userLoadedBitmap != null) {
                        drawImage(
                            image = userLoadedBitmap!!.asImageBitmap(),
                            dstSize = androidx.compose.ui.unit.IntSize(w.toInt(), h.toInt())
                        )
                    } else {
                        // Synthetic paper
                        drawRect(Color(0xFFFDFBF7))

                        when (selectedPaperType) {
                            PaperType.LINED_NOTEBOOK -> {
                                var y = startOffsetY
                                while (y < h - 40f) {
                                    drawLine(
                                        color = Color(0x334B8BEB),
                                        start = Offset(40f, y),
                                        end = Offset(w - 40f, y),
                                        strokeWidth = 1.2f
                                    )
                                    y += lineSpacing
                                }
                                // Margin line
                                drawLine(
                                    color = Color(0x44EF4444),
                                    start = Offset(w - 60f, 0f),
                                    end = Offset(w - 60f, h),
                                    strokeWidth = 1.5f
                                )
                            }
                            PaperType.GRID_PAPER -> {
                                val step = 28f
                                var x = 20f
                                while (x < w - 20f) {
                                    drawLine(Color(0x1F6B7280), Offset(x, 0f), Offset(x, h), 1f)
                                    x += step
                                }
                                var y = 20f
                                while (y < h - 20f) {
                                    drawLine(Color(0x1F6B7280), Offset(0f, y), Offset(w, y), 1f)
                                    y += step
                                }
                            }
                            else -> {}
                        }
                    }

                    // 2. Render Handwritten Text along lines
                    val nativeCanvas = drawContext.canvas.nativeCanvas
                    val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
                        color = inkColorArgb.toInt()
                        textSize = fontSize * density
                        textAlign = AndroidPaint.Align.RIGHT
                        if (customTypeface != null) {
                            typeface = customTypeface
                        }
                    }

                    val paragraphs = textInput.split("\n")
                    var currentY = startOffsetY
                    val margin = 50f
                    val maxTextWidth = w - margin * 2

                    for (para in paragraphs) {
                        val words = para.split(" ")
                        var currentLine = ""

                        for (word in words) {
                            val candidate = if (currentLine.isEmpty()) word else "$currentLine $word"
                            val measured = paint.measureText(candidate)
                            if (measured > maxTextWidth && currentLine.isNotEmpty()) {
                                nativeCanvas.save()
                                nativeCanvas.rotate(textSlopeAngle, w - margin, currentY)
                                nativeCanvas.drawText(currentLine, w - margin, currentY, paint)
                                nativeCanvas.restore()

                                currentY += lineSpacing
                                currentLine = word
                            } else {
                                currentLine = candidate
                            }
                        }

                        if (currentLine.isNotEmpty()) {
                            nativeCanvas.save()
                            nativeCanvas.rotate(textSlopeAngle, w - margin, currentY)
                            nativeCanvas.drawText(currentLine, w - margin, currentY, paint)
                            nativeCanvas.restore()
                            currentY += lineSpacing
                        }
                    }
                }
            }

            // Text Input
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                label = { Text("متن دست‌نویس روی کاغذ") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("paper_text_input"),
                shape = RoundedCornerShape(12.dp)
            )

            // Adjustments: Font size, Line Spacing, Tilt
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("فاصله خطوط (Line Spacing):", fontSize = 12.sp)
                        Text("${lineSpacing.toInt()} px", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = lineSpacing,
                        onValueChange = { lineSpacing = it },
                        valueRange = 25f..80f
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("شیب خطوط (Slope Angle):", fontSize = 12.sp)
                        Text("${String.format("%.1f", textSlopeAngle)}°", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = textSlopeAngle,
                        onValueChange = { textSlopeAngle = it },
                        valueRange = -5f..5f
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ارتفاع شروع متن:", fontSize = 12.sp)
                        Text("${startOffsetY.toInt()} px", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = startOffsetY,
                        onValueChange = { startOffsetY = it },
                        valueRange = 30f..250f
                    )
                }
            }
        }
    }
}

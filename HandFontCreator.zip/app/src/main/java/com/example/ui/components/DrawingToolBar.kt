package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.PenType
import com.example.data.models.PencilHardness
import com.example.data.models.ToolType

data class NamedColor(val name: String, val argb: Long)

val PENCIL_PALETTE = listOf(
    NamedColor("Graphite", 0xFF2F3237L),
    NamedColor("Light Gray", 0xFF888888L),
    NamedColor("Medium Gray", 0xFF555555L),
    NamedColor("Dark Gray", 0xFF333333L),
    NamedColor("Graphite Black", 0xFF181818L),
    NamedColor("Pencil Blue", 0xFF2B4C7EL),
    NamedColor("Pencil Red", 0xFF7E2B2BL),
    NamedColor("Pencil Green", 0xFF2B6E3AL)
)

val PEN_PALETTE = listOf(
    NamedColor("Blue Pen", 0xFF1E3A8AL),
    NamedColor("Black Pen", 0xFF0A0A0AL),
    NamedColor("Red Pen", 0xFF991B1BL),
    NamedColor("Green Pen", 0xFF065F46L)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrawingToolBar(
    modifier: Modifier = Modifier,
    currentTool: ToolType,
    currentColorArgb: Long,
    currentStrokeWidth: Float,
    pencilHardness: PencilHardness,
    penType: PenType,
    canUndo: Boolean,
    canRedo: Boolean,
    onToolSelected: (ToolType) -> Unit,
    onColorSelected: (Long) -> Unit,
    onStrokeWidthChanged: (Float) -> Unit,
    onPencilHardnessSelected: (PencilHardness) -> Unit,
    onPenTypeSelected: (PenType) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onClear: () -> Unit,
    onConfirm: () -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f),
        tonalElevation = 6.dp,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Row 1: Action bar (Undo, Redo, Clear, Confirm)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onUndo,
                        enabled = canUndo,
                        modifier = Modifier.testTag("undo_button")
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo")
                    }
                    IconButton(
                        onClick = onRedo,
                        enabled = canRedo,
                        modifier = Modifier.testTag("redo_button")
                    ) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo")
                    }
                    IconButton(
                        onClick = onClear,
                        modifier = Modifier.testTag("clear_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear", tint = MaterialTheme.colorScheme.error)
                    }
                }

                // Tool selector chips
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = currentTool == ToolType.PENCIL,
                        onClick = { onToolSelected(ToolType.PENCIL) },
                        label = { Text("✏ مداد", fontSize = 12.sp) },
                        modifier = Modifier.testTag("tool_pencil")
                    )
                    FilterChip(
                        selected = currentTool == ToolType.PEN,
                        onClick = { onToolSelected(ToolType.PEN) },
                        label = { Text("🖊 خودکار", fontSize = 12.sp) },
                        modifier = Modifier.testTag("tool_pen")
                    )
                    FilterChip(
                        selected = currentTool == ToolType.ERASER,
                        onClick = { onToolSelected(ToolType.ERASER) },
                        label = { Text("🧽 پاک‌کن", fontSize = 12.sp) },
                        modifier = Modifier.testTag("tool_eraser")
                    )
                }

                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("confirm_button")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("تأیید", fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(6.dp))

            // Row 2: Hardness or Pen Type Sub-options
            if (currentTool == ToolType.PENCIL) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("درجه مداد:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    PencilHardness.values().forEach { hardness ->
                        FilterChip(
                            selected = pencilHardness == hardness,
                            onClick = { onPencilHardnessSelected(hardness) },
                            label = { Text(hardness.code, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer
                            )
                        )
                    }
                }
            } else if (currentTool == ToolType.PEN) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("نوع قلم:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    PenType.values().forEach { pt ->
                        FilterChip(
                            selected = penType == pt,
                            onClick = { onPenTypeSelected(pt) },
                            label = { Text(pt.title, fontSize = 11.sp) }
                        )
                    }
                }
            }

            // Row 3: Color Palette & Stroke Width
            if (currentTool != ToolType.ERASER) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Color swatches
                    val palette = if (currentTool == ToolType.PENCIL) PENCIL_PALETTE else PEN_PALETTE
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        palette.forEach { item ->
                            val isSelected = currentColorArgb == item.argb
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(item.argb))
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray,
                                        shape = CircleShape
                                    )
                                    .clickable { onColorSelected(item.argb) }
                            )
                        }
                    }

                    // Stroke size slider
                    Row(
                        modifier = Modifier.width(140.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${currentStrokeWidth.toInt()}px", fontSize = 11.sp)
                        Slider(
                            value = currentStrokeWidth,
                            onValueChange = onStrokeWidthChanged,
                            valueRange = 4f..36f,
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

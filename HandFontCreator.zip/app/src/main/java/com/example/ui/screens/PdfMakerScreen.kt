package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.engine.pdf.PageSize
import com.example.engine.pdf.PdfConfig
import com.example.engine.pdf.PdfTemplate
import com.example.ui.viewmodel.FontStudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfMakerScreen(
    viewModel: FontStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val exportedPdf by viewModel.exportedPdfFile.collectAsState()

    var textInput by remember {
        mutableStateOf(
            "به نام خدا\n\nاین یک نمونه متن چندصفحه‌ای برای تبدیل به سند دست‌نویس با فونت واقعی است.\n" +
                    "با استفاده از موتور پردازش دستخط، تمامی کلمات با فرم‌های مناسب، تراز خطوط دفتر، و کمی تنوع طبیعی قلم روی صفحه نوشته می‌شوند.\n\n" +
                    "امکان ساخت جزوه، مشق شب، نامه اداری، و مقالات دانشگاهی با دستخط شخصی وجود دارد."
        )
    }

    var selectedPageSize by remember { mutableStateOf(PageSize.A4) }
    var selectedTemplate by remember { mutableStateOf(PdfTemplate.LINED) }
    var fontSize by remember { mutableFloatStateOf(16f) }
    var lineSpacing by remember { mutableFloatStateOf(34f) }
    var showPageNumbers by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ساخت PDF دستنویس", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("pdf_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (exportedPdf != null) {
                        IconButton(
                            onClick = {
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.provider",
                                    exportedPdf!!
                                )
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "اشتراک‌گذاری PDF"))
                            },
                            modifier = Modifier.testTag("share_pdf_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share PDF")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("pdf_maker_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // PDF Result card if already generated
            if (exportedPdf != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pdf_generated_card"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("PDF با موفقیت ساخته شد", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(exportedPdf!!.name, fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                        }
                        Button(
                            onClick = {
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.provider",
                                    exportedPdf!!
                                )
                                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(uri, "application/pdf")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(viewIntent, "مشاهده PDF"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("مشاهده", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Text Input
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                label = { Text("متن دست‌نویس برای PDF") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .testTag("pdf_text_input"),
                shape = RoundedCornerShape(12.dp)
            )

            // Page Size Selector
            Text("اندازه صفحه (Page Size):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PageSize.values().forEach { size ->
                    FilterChip(
                        selected = selectedPageSize == size,
                        onClick = { selectedPageSize = size },
                        label = { Text(size.title, fontSize = 12.sp) }
                    )
                }
            }

            // Template Selector
            Text("قالب صفحه (Template):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PdfTemplate.values().forEach { tmpl ->
                    FilterChip(
                        selected = selectedTemplate == tmpl,
                        onClick = { selectedTemplate = tmpl },
                        label = { Text(tmpl.title, fontSize = 12.sp) }
                    )
                }
            }

            // Configuration Sliders
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("اندازه قلم:", fontSize = 12.sp)
                        Text("${fontSize.toInt()} pt", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = fontSize,
                        onValueChange = { fontSize = it },
                        valueRange = 12f..32f
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("فاصله خطوط:", fontSize = 12.sp)
                        Text("${lineSpacing.toInt()} pt", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = lineSpacing,
                        onValueChange = { lineSpacing = it },
                        valueRange = 24f..54f
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("نمایش شماره صفحه:", fontSize = 12.sp)
                        Switch(
                            checked = showPageNumbers,
                            onCheckedChange = { showPageNumbers = it }
                        )
                    }
                }
            }

            // Generate Button
            Button(
                onClick = {
                    val config = PdfConfig(
                        pageSize = selectedPageSize,
                        template = selectedTemplate,
                        fontSize = fontSize,
                        lineSpacing = lineSpacing,
                        showPageNumbers = showPageNumbers
                    )
                    viewModel.generatePdf(textInput, config)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("generate_pdf_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("تولید PDF دستنویس چندصفحه‌ای", fontWeight = FontWeight.Bold)
            }
        }
    }
}
